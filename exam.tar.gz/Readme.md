## Code Submission Requirements:
 1. Use of any scripting language is fine, but prefer python or bash.
 2. Your script should be accompanied by a Readme.md file that contains a brief description and usage of your script.
 3. If your script will require a special yum/deb package, indicate the exact package name and version number in the Readme.md file.
 4. Submission of code is thru bitbucket or github or any public git repo you prefer. Send the git repo url to jefferson@techasiaportal.com 

## Instruction
Given the following sample nginx access.log file, I want a script that will monitor the file and show continously how many a particular HTTP code has appeared since the script was executed.

## Example Output
```
$ yourscript.sh access.log

# the output should be something like this.
======= Starting
http code 200: 1
http code 404: 2
http code 444: 2
========
http code 200: 2
http code 404: 2
http code 444: 2
========
http code 200: 3
http code 404: 2
http code 444: 2
========
http code 200: 3
http code 404: 2
http code 444: 3
========
http code 200: 3
http code 404: 2
http code 444: 4
